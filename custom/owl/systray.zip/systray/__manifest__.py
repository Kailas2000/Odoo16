{
    "name": "Systray Increment",
    "depends": ["web"],
    "version": "16.0.1.0.0",
    "assets": {
        "web.assets_backend": [
            "/systray/static/src/js/increment.js",
            "/systray/static/src/xml/increment.xml"
        ]
    }
}