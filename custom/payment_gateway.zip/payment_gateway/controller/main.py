# -*- coding: utf-8 -*-
import logging
import pprint
from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)


class RazorPayController(http.Controller):
    @http.route(
        '/razor/payment-success', type='http', methods=['GET', 'POST'],
        auth='public', save_session=False, csrf=False)

    def razorpay_return_from_checkout(self, **data):
        print(data, 'data')
        """Process the notification data sent by APS after redirection"""
        _logger.info("Handling redirection from paytrail with data:\n%s",
                     pprint.pformat(data))

        # Check the integrity of the notification.
        tx_sudo = request.env['payment.transaction'].sudo()._get_tx_from_notification_data(
            'razorpayment', data
        )
        # self._verify_notification_signature(data, tx_sudo)

        # Handle the notification data.
        tx_sudo._handle_notification_data('aps', data)
        return request.redirect('/payment/status')
