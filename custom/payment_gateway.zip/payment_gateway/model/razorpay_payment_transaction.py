# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging
import razorpay
from odoo import _, models
from odoo.exceptions import ValidationError

client = razorpay.Client(auth=("rzp_test_o36UiDz9mXH4ls", "iKGlIK4BqUyorTzWE6W2qsIQ"))
_logger = logging.getLogger(__name__)


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    def _get_specific_rendering_values(self, processing_values):
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider_code != 'razorpayment':
            return res
        DATA = {
            "amount": float(processing_values.get('amount')) *100,
            "currency": "INR",
            "receipt": "receipt#1",
        }
        order = client.order.create(data=DATA)
        print(order)
        # Initiate the payment
        base_url = self.provider_id.get_base_url()
        print(base_url, 'base')
        return_url_params = {'reference': self.reference}
        print(return_url_params, 'return')

        rendering_values = {
            'key_id': 'rzp_test_o36UiDz9mXH4ls',
            'name': self.company_id.name,
            'description': self.reference,
            'order_id': order['id'],
            'amount': order['amount'],
            'currency': order['currency'],
            'partner_name': self.partner_name,
            'partner_email': self.partner_email,
            'return_url': base_url + "razor/payment-success",
        }
        return rendering_values

    def _get_tx_from_notification_data(self, provider_code, notification_data):
        """ Override of `payment` to find the transaction based on APS data.

        :param str provider_code: The code of the provider that handled the transaction.
        :param dict notification_data: The notification data sent by the provider.
        :return: The transaction if found.
        :rtype: recordset of `payment.transaction`
        :raise ValidationError: If inconsistent data are received.
        :raise ValidationError: If the data match no transaction.
        """
        tx = super()._get_tx_from_notification_data(provider_code, notification_data)
        if provider_code != 'razorpayment' or len(tx) == 1:
            return tx
        print(notification_data, 'noti')
        reference = notification_data.get('merchant_reference')
        if not reference:
            raise ValidationError(
                "RAZORPAY: " + _("Received data with missing reference %(ref)s.", ref=reference)
            )

        tx = self.search([('reference', '=', reference), ('provider_code', '=', 'razorpayment')])
        if not tx:
            raise ValidationError(
                "RAZORPAY: " + _("No transaction found matching reference %s.", reference)
            )

        return tx