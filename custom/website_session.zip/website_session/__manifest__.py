{
    'name': 'Website Session',
    'version': '16.0.1.0.0',
    'depends': ['website'],
    'data':[
        'data/website_menu.xml',
        'views/website_partner_template.xml'
    ],

}